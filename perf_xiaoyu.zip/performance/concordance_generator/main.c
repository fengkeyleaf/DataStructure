
/*
 * main.c
 *
 * -std=c99
 *
 * @author Xiaoyu Tongyang, or call me sora for short
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>

#include "bs_tree.h"
#include "rb_tree.h"
#include "vector.h"

/**
 * Integer wrapper to fit into a generic data structure.
 * */

typedef struct Integer_s {
    size_t num;
} Integer_t;

int cur_line = 0;
bool is_RBT = false;

//-------------------------------------------------------
// traverse method
//-------------------------------------------------------

void rbt_traverse_( const RBNode_t* node ) {
    if( node == NULL ) return;

    rbt_traverse_( node->left );

    Vector_t *V = ( Vector_t * ) node->val;
    printf( "%s (%lu): %lu", ( ( char * ) node->key ), V->len, *( size_t * ) V->data[ 0 ] );
    for( size_t i = 1; i < V->len; ++i ) {
        printf( ", %lu", *( size_t * ) V->data[ i ] );
    }
    putchar( '\n' );

    rbt_traverse_( node->right );
}

/**
 * Traverse the red-black tree in-order and print out each word
 * */

void rbt_traverse( const RBTree_t* tree ) {
    rbt_traverse_( tree->root );
}

void bst_traverse_( const BSNode_t* node ) {
    if( node == NULL ) return;

    bst_traverse_( node->left );

    Vector_t *V = ( Vector_t * ) node->val;
    printf( "%s (%lu): %lu", ( ( char * ) node->key ), V->len, *( size_t * ) V->data[ 0 ] );
    for( size_t i = 1; i < V->len; ++i ) {
        printf( ", %lu", *( size_t * ) V->data[ i ] );
    }
    putchar( '\n' );

    bst_traverse_( node->right );
}

/**
 * Traverse the binary search tree in-order and print out each word
 * */

void bst_traverse( const BSTree_t* tree ) {
    bst_traverse_( tree->root );
}

/**
 * key comparison function for the trees.
 * */

int chars_compare( const void *a, const void *b ) {
    return strcasecmp( a, b );
}

//-------------------------------------------------------
// deconstructor
//-------------------------------------------------------

/**
 * Vector deconstructor for the vectors stored in the tree nodes.
 * */

void vector_decon( void **data, size_t len ) {
    for ( size_t i = 0; i < len; i++ ) {
        free( data[ i ] );
    }
}

/**
 * Val deconstructor for Red-black tree node.
 * */

void rbt_tree_node_decon( RBNode_t *n ) {
    free( ( void * ) n->key );

    Vector_t *V = n->val;
    vec_cleanup( V );
    free( V );
}

/**
 * Val deconstructor for Binary search tree node.
 * */

void bst_tree_node_decon( BSNode_t *n ) {
    free( ( void * ) n->key );

    Vector_t *V = n->val;
    vec_cleanup( V );
    free( V );
}

//-------------------------------------------------------
// insert
//-------------------------------------------------------

/**
 * Insert a word into the red-black tree.
 * */

void rbt_insert( RBTree_t *tree, const char *word ) {
    Vector_t *val = rbt_get( tree, word );
    if ( val == NULL ) {
        Vector_t *V = calloc( 1, sizeof( Vector_t ) );
        vector_default( V );
        V->data_deco = vector_decon;

        Integer_t *n = calloc( 1, sizeof( Integer_t ) );
        n->num = cur_line;

        vec_append( V, n );
        rbt_put( tree, word, V );
        return;
    }

    // Not put into the tree, free here.
    free( ( void * ) word );

    Integer_t *n = calloc( 1, sizeof( Integer_t ) );
    n->num = cur_line;
    vec_append( val, n );
}

/**
 *  Insert a word into the binary search tree.
 * */

void bst_insert( BSTree_t *tree, const char *word ) {
    Vector_t *val = bst_get( tree, word );
    if ( val == NULL ) {
        Vector_t *V = calloc( 1, sizeof( Vector_t ) );
        vector_default( V );
        V->data_deco = vector_decon;

        Integer_t *n = calloc( 1, sizeof( Integer_t ) );
        n->num = cur_line;

        vec_append( V, n );
        bst_put( tree, word, V );
        return;
    }

    // Not put into the tree, free here.
    free( ( void * ) word );

    Integer_t *n = calloc( 1, sizeof( Integer_t ) );
    n->num = cur_line;
    vec_append( val, n );
}

// Adopted from ChatGPT
void process_tokens( RBTree_t *rb_tree, BSTree_t *bs_tree ) {
    int error_number;
    PCRE2_SIZE error_offset;

    // compile expr for tokenizing words
    // valid words are defined as sequences of
    // letters, digits, apostrophes, underscores, and hyphens
    PCRE2_SPTR pattern = ( PCRE2_SPTR ) "[A-Za-z0-9'_-]+";
    pcre2_code *re = pcre2_compile(
        pattern, PCRE2_ZERO_TERMINATED, 0,
        &error_number, &error_offset, NULL
    );

    // check for compilation errors
    if ( re == NULL ) {
        PCRE2_UCHAR buffer[ 256 ];
        pcre2_get_error_message( error_number, buffer, sizeof( buffer ) );
        fprintf(
            stderr, "PCRE2 compile error at offset %d: %s\n",
            ( int ) error_offset, ( const char * ) buffer
        );

        return;
    }

    char *line = NULL;
    size_t cap = 0;
    ssize_t len;

    // read lines from stdin
    while ( ( len = getline( &line, &cap, stdin ) ) != -1 ) {
        cur_line++;

        PCRE2_SPTR subject = ( PCRE2_SPTR )line;
        size_t subject_length = ( size_t )len;

        // create match data block
        pcre2_match_data *match_data = pcre2_match_data_create_from_pattern( re, NULL );
        PCRE2_SIZE start_offset = 0;

        // find all matches in the line
        while ( true ) {
            int rc = pcre2_match(
                re, subject, subject_length, start_offset,
                0, match_data, NULL
            );

            if ( rc <= 0 ) break; // no more matches in this line

            // Get the matched word
            PCRE2_SIZE *ovector = pcre2_get_ovector_pointer( match_data );
            PCRE2_SIZE start = ovector[ 0 ];
            PCRE2_SIZE end   = ovector[ 1 ];

            // Copy the matched word
            size_t size = end - start;
            char *key = calloc( 1, ( len + 1 ) * sizeof( char ) );
            assert( key );
            memcpy( key, subject + start, size );
            key[ len ] = '\0';   // null terminate

            // insert into trees
//            bst_insert( bs_tree, key );
            rbt_insert( rb_tree, key );

            start_offset = end;
        }

        pcre2_match_data_free( match_data );
    }

    free( line );
    pcre2_code_free( re );
}

int main( int argc, char *argv[] ) {
    // pointer to the root of the binary tree
    RBTree_t rb_tree = { NULL,chars_compare, rbt_tree_node_decon };
    BSTree_t bs_tree = { NULL,chars_compare, bst_tree_node_decon };

    ( void ) argv[ 0 ]; // silence unused parameter warning

    // check command line arguments
    if ( argc != 1 ) {
        fprintf( stderr, "usage: concordance\n" );
        return EXIT_FAILURE;
    }

    // read from stdin, tokenize, and insert into the tree
    process_tokens( &rb_tree, &bs_tree );

    if( rbt_is_empty( &rb_tree ) && bst_is_empty( &bs_tree ) ) {
        // no words in the tree!
        fputs( "concordance: no words in the input\n", stderr );
        return EXIT_FAILURE;
    }

    // traverse and print the tree
//    rbt_traverse( &rb_tree );
//    bst_traverse( &bs_tree );

    // print the depths of the trees
    printf( "Max RBT Depth: %lu\n", rbt_max_depth( &rb_tree ) );
    printf( "Max BST Depth: %lu\n", bst_max_depth( &bs_tree ) );

    // clean up
    rbt_cleanup( &rb_tree );
    bst_cleanup( &bs_tree );

    return EXIT_SUCCESS;
}