#include <stdio.h>
#include <stdlib.h>

#include "rb_tree.h"   // from redblacktree/include
#include "vector.h"   // from vector/include

int char_compare( const void *a, const void *b ) {
    const char *ia = a;
    const char *ib = b;
    return ( *ia > *ib ) - ( *ia < *ib );
}

void vec_print( const Vector_t *V ) {
    for ( size_t i = 0; i < V->len; ++i ) {
        printf( "%d, ", *( int * ) V->data[ i ] );
    }
    printf( "\n" );
}

void inorder_print_( const RBNode_t *root ) {
    if ( root == NULL ) return;

    inorder_print_( root->left );
    printf( "%c => ", * ( ( char* ) root->key ) );
    const Vector_t *V = root->val;
    vec_print( V );
    inorder_print_( root->right );
}

void inorder_print( const RBNode_t *root ) {
    inorder_print_( root );
    printf( "\n" );
}

void get_print( const RBTree_t *tree, char *c ) {
    printf( "get(%c)= ", *c );
    Vector_t *V = rbt_get( tree, c );
    if ( V == NULL ) {
        printf( "null\n" );
        return;
    }
    vec_print( V );
}

void rbt_tree_node_decon( RBNode_t *n ) {
    Vector_t *V = n->val;
    vec_cleanup( V );
}

void test_RBtree_vector() {
    RBTree_t tree = { NULL,char_compare, rbt_tree_node_decon };

    size_t num1 = 1;
    size_t num2 = 2;
    size_t num3 = 3;
    size_t num4 = 4;
    size_t num5 = 5;
    size_t num6 = 6;
    size_t num7 = 7;
    size_t num8 = 8;
    size_t num9 = 9;
    size_t num10 = 10;

    char S = 'S';
    Vector_t V1;
    vector_default( &V1 );
    vec_append( &V1, &num1 );
    vec_append( &V1, &num2 );
    rbt_put( &tree, &S, &V1 );

    char E = 'E';
    Vector_t V2;
    vector_default( &V2 );
    vec_append( &V2, &num2 );
    vec_append( &V2, &num3 );
    rbt_put( &tree, &E, &V2 );

    char A = 'A';
    Vector_t V3;
    vector_default( &V3 );
    vec_append( &V3, &num3 );
    vec_append( &V3, &num4 );
    rbt_put( &tree, &A, &V3 );

    char R = 'R';
    Vector_t V4;
    vector_default( &V4 );
    vec_append( &V4, &num4 );
    vec_append( &V4, &num5 );
    rbt_put( &tree, &R, &V4 );

    char C = 'C';
    Vector_t V5;
    vector_default( &V5 );
    vec_append( &V5, &num5 );
    vec_append( &V5, &num6 );
    rbt_put( &tree, &C, &V5 );

    char H = 'H';
    Vector_t V6;
    vector_default( &V6 );
    vec_append( &V6, &num6 );
    vec_append( &V6, &num7 );
    rbt_put( &tree, &H, &V6 );

    char X = 'X';
    Vector_t V7;
    vector_default( &V7 );
    vec_append( &V7, &num7 );
    vec_append( &V7, &num8 );
    rbt_put( &tree, &X, &V7 );

    char M = 'M';
    Vector_t V8;
    vector_default( &V8 );
    vec_append( &V8, &num8 );
    vec_append( &V8, &num9 );
    rbt_put( &tree, &M, &V8 );

    char P = 'P';
    Vector_t V9;
    vector_default( &V9 );
    vec_append( &V9, &num9 );
    vec_append( &V9, &num10 );
    rbt_put( &tree, &P, &V9 );

    char L = 'L';
    Vector_t V10;
    vector_default( &V10 );
    vec_append( &V10, &num10 );
    vec_append( &V10, &num1 );
    rbt_put( &tree, &L, &V10 );

    inorder_print( tree.root );

    get_print( &tree, &M );
    get_print( &tree, &A );
    get_print( &tree, &X );
    char O = 'O';
    get_print( &tree, &O );

    rbt_cleanup( &tree );
}

int main( int argc, char *argv[] ) {
    test_RBtree_vector();

    return 0;
}