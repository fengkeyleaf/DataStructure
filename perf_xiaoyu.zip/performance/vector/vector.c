#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "vector.h"

// manage operations

/**
 * Rearranges the vector by extending or shrinking its capacity based on its length.
 * */

static inline void rearrange( Vector_t *v );

/**
 * Extends the vector's capacity when its length reaches its current capacity.
 * The capacity is doubled
 * */

static inline void extend( Vector_t *v );

/**
 * Shrinks the vector's capacity
 * when its length is less than or equal to one-fourth of its capacity,
 * and the halved capacity is greater than the default capacity.
 * The capacity is halved.
 * */

static inline void shrink( Vector_t *v );

void vector( Vector_t *v, const void **data, size_t len ) {
    v->len = len;
    v->cap = len * 2;
    v->data = ( void ** ) calloc( 1, v->cap * sizeof( void * ) );
    assert( v->data );
    memcpy( v->data, data, len * sizeof( void * ) );
}

void vector_capacity( Vector_t *v, size_t cap ) {
    v->cap = cap < DEFAULT_CAPACITY ? DEFAULT_CAPACITY : cap;
    v->len = 0;
    v->data = ( void ** ) calloc( 1, cap * sizeof( void * ) );
}

void vector_default( Vector_t *v ) {
    vector_capacity( v, DEFAULT_CAPACITY );
}

void vec_append( Vector_t *v, void *ele ) {
    v->data[ v->len++ ] = ele;

    rearrange( v );
}

void rearrange( Vector_t *v ) {
    if ( v->len >= v->cap ) {
        extend( v );
    }

    if (
        ( v->len <= v->cap / 4 ) &&
        ( v->cap / 2 > DEFAULT_CAPACITY )
    ) {
        shrink( v );
    }
}

void extend( Vector_t *v ) {
    v->cap *= 2;
    void **D = ( void ** ) realloc( v->data, v->cap * sizeof( void * ) );
    assert( v->data );
    v->data = D;
}

void shrink( Vector_t *v ) {
    v->cap /= 2;
    void **D = ( void ** ) realloc( v->data, v->cap * sizeof( void * ) );
    assert( v->data );
    v->data = D;
}

void *vec_get( const Vector_t* v, int idx ) {
    if ( vec_is_empty( v ) ) {
        perror( "Error: vector is empty\n" );
        exit( 1 );
    }

    if ( idx < 0 || idx >= ( int ) v->len ) {
        perror( "Error: idx is out of boundary!\n" );
        exit( 1 );
    }

    return v->data[ idx ];
}

void vec_cleanup( Vector_t *v ) {
    assert( v->data != NULL );
    if ( v->data_deco ) v->data_deco( v->data, v->len );
    free( v->data );
}