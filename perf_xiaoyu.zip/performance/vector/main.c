#include <stdio.h>

#include "vector.h"

int main( int argc, char *argv[] ) {
    Vector_t V;
    vector_default( &V );

    int num1 = 1;
    int num2 = 2;
    int num3 = 3;
    int num4 = 4;
    int num5 = 5;
    int num6 = 6;

    vec_append( &V, &num1 );
    vec_append( &V, &num2 );
    vec_append( &V, &num3 );
    vec_append( &V, &num4 );
    vec_append( &V, &num5 );
    vec_append( &V, &num6 );
    vec_append( &V, &num5 );
    vec_append( &V, &num4 );
    vec_append( &V, &num3 );
    vec_append( &V, &num2 );
    vec_append( &V, &num1 );

    for ( size_t i = 0; i < V.len; ++i ) {
        printf( "%d, ", *( int * ) V.data[ i ] );
    }

    vec_cleanup( &V );
    return 0;
}