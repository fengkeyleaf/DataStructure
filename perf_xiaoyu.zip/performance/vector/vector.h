#ifndef VECTOR_VECTOR_H
#define VECTOR_VECTOR_H

/*
 * vector.h
 *
 * -std=c99
 *
 * @author Xiaoyu Tongyang, or call me sora for short
 */

#include <stdbool.h>

// Reference materials:
// https://github.com/fengkeyleaf/TeachingPlatform/tree/Version-2.1

#define DEFAULT_CAPACITY 8

/**
 * Data array deconstruction function pointer type,
 * defined to free the value stored in the data array if provided.
 * */

typedef void ( *vec_free_func )( void **data, size_t len );

/**
 * Vector structure definition
 * */

typedef struct Vector_s {
    // Data array
    void **data;
    // Actual size
    size_t len;
    // Capacity
    size_t cap;
    // Data deconstruction function pointer
    // When it is NULL, no deconstruction will be performed.
    // otherwise, it will be called when a vector is deleted.
    // Must be initialized to NULL, or function pointer.
    vec_free_func data_deco;
} Vector_t;

// constructors

/**
 * Initialize a vector with given data array.
 * All data will be copied to the vector.
 * Capacity will be set to two times the length of data array.
 *
 * You must free the vector before calling this constructor if it is initialized.
 * */

void vector( Vector_t *v, const void **data, size_t len );

/**
 * Initialize a vector with given capacity.
 * if cap is less than DEFAULT_CAPACITY, it will be set to DEFAULT_CAPACITY.
 * Size will be set to zero.
 *
 * You must free the vector before calling this constructor if it is initialized.
 * */

void vector_capacity( Vector_t *v, size_t cap );

/**
 * Initialize a vector with default capacity (8).
 *
 * You must free the vector before calling this constructor if it is initialized.
 * */

void vector_default( Vector_t *v );

// add operations

/**
 * Append an element to the end of the vector.
 * */

void vec_append( Vector_t *v, void *ele );

// obtain operations

/**
 * Check if the vector is empty.
 * */

static inline bool vec_is_empty( const Vector_t *v ) {
    return v->len == 0;
}

/**
 * Get the element at the given index.
 * */

void *vec_get( const Vector_t* v, int index );

// deconstrcutor

/**
 * Deconstruct the vector.
 * */

void vec_cleanup( Vector_t *v );

// TODO: Support more operations.

#endif // VECTOR_VECTOR_H