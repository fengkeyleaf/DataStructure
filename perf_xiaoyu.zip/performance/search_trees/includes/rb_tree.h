#ifndef RED_BLACK_TREE_RB_TREE_H
#define RED_BLACK_TREE_RB_TREE_H

/*
 * rb_tree.h
 *
 * -std=c99
 *
 * @author Xiaoyu Tongyang, or call me sora for short
 */

#include <stdbool.h>

#include "vector.h"

// Reference materials:
// https://github.com/fengkeyleaf/Algorithm/blob/main/Java/com/fengkeyleaf/util/tree/RedBlackTree.java

#define RED true
#define BLACK false

/**
 * Data structure of RB tree node with mapping, key -> value
 * */

typedef struct RBNode_s {
    bool color;
    const void *key;
    void *val;
    // Number of nodes in subtree rooted here.
    size_t size;
    struct RBNode_s *left;
    struct RBNode_s *right;
} RBNode_t;

/**
 * Comparison function pointer type
 * */

typedef int ( *rbt_compare_fnc )( const void *, const void * );

/**
 * Value deconstruction function pointer type,
 * defined to free the value stored in a tree node if provided.
 * */

typedef void ( *rbt_free_func )( RBNode_t * );

/**
 * Data structure of Red Black Tree
 * with mapping tree node.
 */

typedef struct RBTree_s {
    // Must be initialized to NULL.
    RBNode_t *root;
    // Key comparison function
    // Must be initialized to a function pointer.
    rbt_compare_fnc comp;
    // Value deconstruction function.
    // When it is NULL, no deconstruction will be performed.
    // otherwise, it will be called when a node is deleted.
    // Must be initialized to NULL, or function pointer.
    rbt_free_func val_decon;
} RBTree_t;

/**
 * put key -> val into this R-B tree
 *
 * @param key  the key. Cannot be NULL.
 * @param val  the value. Delete the entry if val is NULL. (Not implemented yet)
 * */

void rbt_put( RBTree_t *tree, const void *key, void *val );

/**
 * get the value associated with the key
 *
 * @param key  the key. Cannot be NULL.
 * */

void *rbt_get( const RBTree_t *tree, const void *key );

/**
 * Free all nodes in this RBT
 * */

void rbt_cleanup( RBTree_t *tree );

/**
 * is this tree empty?
 * */

bool rbt_is_empty( const RBTree_t *tree );

/**
 * Get all keys in this RBT in sorted order defined by the comparison function.
 * */

Vector_t *rbt_keys( const RBTree_t *tree );

/**
 * Get the max depth of this RBT
 * */

size_t rbt_max_depth( const RBTree_t *tree );

// TODO: delete(), etc.,

#endif //RED_BLACK_TREE_RB_TREE_H