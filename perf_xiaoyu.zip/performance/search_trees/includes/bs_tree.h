#ifndef RED_BLACK_TREE_BS_TREE_H
#define RED_BLACK_TREE_BS_TREE_H

/*
 * bs_tree.h
 *
 * -std=c99
 *
 * @author Xiaoyu Tongyang, or call me sora for short
 */

#include <stdbool.h>

#include "vector.h"

// reference materials:
// https://github.com/fengkeyleaf/Algorithm/blob/main/Java/com/fengkeyleaf/util/tree/BinarySearchTree.java

/**
 * Data structure of tree node with mapping, key -> value
 * */

typedef struct BSNode_s {
    const void *key;
    void *val;
    // Number of nodes in subtree rooted here.
    size_t size;
    struct BSNode_s *left;
    struct BSNode_s *right;
} BSNode_t;

/**
 * Comparison function pointer type
 * */

typedef int ( *bst_compare_fnc )( const void *, const void * );

/**
 * Value deconstruction function pointer type,
 * defined to free the value stored in a tree node if provided.
 * */

typedef void ( *bst_free_func )( BSNode_t * );

/**
 * Data structure of Binary Search Tree
 * with mapping tree node.
 */

typedef struct BSTree_s {
    // Must be initialized to NULL.
    BSNode_t *root;
    // Key comparison function
    // Must be initialized to a function pointer.
    bst_compare_fnc comp;
    // Value deconstruction function.
    // When it is NULL, no deconstruction will be performed.
    // otherwise, it will be called when a node is deleted.
    // Must be initialized to NULL, or function pointer.
    bst_free_func val_decon;
} BSTree_t;

/**
 * put key -> val into this BST
 *
 * @param key  the key. Cannot be NULL.
 * @param val  the value. Delete the entry if val is NULL. (Not implemented yet)
 * */

void bst_put( BSTree_t *tree, const void *key, void *val );

/**
 * get the value associated with the key
 *
 * @param key  the key. Cannot be NULL.
 * */

void *bst_get( const BSTree_t *tree, const void *key );

/**
 * Free all nodes in this BST
 * */

void bst_cleanup( BSTree_t *tree );

/**
 * is this tree empty?
 * */

bool bst_is_empty( const BSTree_t *tree );

/**
 * Get all keys in this BST in sorted order defined by the comparison function.
 * */

Vector_t *bst_keys( const BSTree_t *tree );

/**
 * Get the max depth of this BST
 * */

size_t bst_max_depth( const BSTree_t *tree );

// TODO: delete(), etc.,

#endif //RED_BLACK_TREE_BS_TREE_H