#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "../includes/rb_tree.h"

/**
 * Is the key or value null?
 *
 * @param key The key to check. Aborted if null.
 * @param val The value to check. If null, remove the entry.
 * */

static bool is_null( const void *key, const void *val );

/**
 * A node is red?
 * */

static inline bool is_red( RBNode_t *n );

/**
 * Balance Case One:
 * root's left child is RED and
 * the right child is BLACK
 * */

static inline bool if_balanced_case_1( const RBNode_t *n );

/**
 * Balance Case Two:
 * root's left child is RED
 * and the left child's left child is RED
 * */

static inline bool if_balanced_case_2( const RBNode_t *n );

/**
 * Balance Case Three:
 * root's left child is BLACK and
 * the right child is RED
 * */

static inline bool if_balanced_case_3( const RBNode_t *n );

/**
 * Common part for both rotate_left and rotate_right.
 * */

static inline void rotate( RBNode_t *n, RBNode_t *t );

static inline RBNode_t *rotate_left( RBNode_t *node );
static inline RBNode_t *rotate_right( RBNode_t *node );
static inline void flip_colors( RBNode_t *n );
static inline size_t size_( RBNode_t *n );
static inline RBNode_t *update_size( RBNode_t *node );

/**
 * Balance this R-B tree after modifications.
 * */

static RBNode_t *balance( RBNode_t **node );
static RBNode_t *put_( RBNode_t *node, rbt_compare_fnc comp, const void *key, void *val );
static void *get_( const RBNode_t *node, rbt_compare_fnc comp, const void *key );
static void cleanup_( RBNode_t *root, rbt_free_func val_deconstructor );
static void keys_( const RBNode_t *node, Vector_t *keys );
static size_t max_depth_( const RBNode_t *node );

//-------------------------------------------------------
// Balancing helpers
//-------------------------------------------------------

bool is_null( const void *key, const void *val ) {
    if ( key == NULL ) {
        perror( "key in put() of RBTree is null\n" );
        exit( 1 );
    }
    if ( val == NULL ) {
        // TODO: enable delete();
        // delete( key );
        return true;
    }

    return false;
}

bool is_red( RBNode_t *n ) {
    // n cannot be null when evaluating n->color due to short-circuiting.
    return n != NULL && n->color;
}

bool if_balanced_case_1( const RBNode_t *n ) {
    return is_red( n->right ) && !is_red( n->left );
}

bool if_balanced_case_2( const RBNode_t *n ) {
    return is_red( n->left ) && is_red( n->left->left );
}

bool if_balanced_case_3( const RBNode_t *n ) {
    return is_red( n->left ) && is_red( n->right );
}

void rotate( RBNode_t *n, RBNode_t *t ) {
    t->color = n->color;
    n->color = RED;
    t->size = n->size;
    update_size( n );
}

RBNode_t *rotate_left( RBNode_t *n ) {
    RBNode_t *temp = n->right;
    n->right = temp->left;
    temp->left = n;
    rotate( n, temp );
    return temp;
}

RBNode_t *rotate_right( RBNode_t *n ) {
    RBNode_t *temp = n->left;
    n->left = temp->right;
    temp->right = n;
    rotate( n, temp );
    return temp;
}

void flip_colors( RBNode_t *n ) {
    assert( n->left != NULL && n->right != NULL );
    n->color = !n->color;
    n->left->color = !n->left->color;
    n->right->color = !n->right->color;
}

size_t size_( RBNode_t *n ) {
    if ( n == NULL ) return 0;
    return n->size;
}

RBNode_t *update_size( RBNode_t *n ) {
    n->size = size_( n->left ) + size_( n->right ) + 1;
    return n;
}

RBNode_t *balance( RBNode_t **node ) {
    if ( if_balanced_case_1( *node ) ) ( *node ) = rotate_left( *node );
    if ( if_balanced_case_2( *node ) ) ( *node ) = rotate_right( *node );
    if ( if_balanced_case_3( *node ) ) flip_colors( *node );

    return update_size( *node );
}

//-------------------------------------------------------
// put
//-------------------------------------------------------

void rbt_put(
    RBTree_t *tree, const void *key, void *val
) {
    if ( is_null( key, val ) ) return;

    tree->root = put_( tree->root, tree->comp, key, val );
    tree->root->color = BLACK;
}

RBNode_t *put_( RBNode_t *node, rbt_compare_fnc comp, const void *key, void *val ) {
    // base case, attach the new node to this position
    if ( node == NULL ) {
        RBNode_t *n = ( RBNode_t * ) calloc( 1, sizeof( RBNode_t ) );
        assert( n );
        n->color = RED;
        n->key = key;
        n->val = val;
        n->size = 1;
        return n;
    }

    int res = comp( node->key, key );
    // the node should be attached in the left subtree
    if ( res > 0 ) node->left = put_( node->left, comp, key, val );
    // the node should be attached in the right subtree
    else if ( res < 0 ) node->right = put_( node->right, comp, key, val );
    // added before, update value
    else node->val = val;

    // update size and restore this R-B tree
    return balance( &node );
}

//-------------------------------------------------------
// get
//-------------------------------------------------------

void *rbt_get( const RBTree_t *tree, const void *key ) {
    if ( key == NULL ) {
        perror( "key in get() of RBTree is null\n" );
        exit( 1 );
    }

    return get_( tree->root, tree->comp, key );
}

void *get_( const RBNode_t *node, rbt_compare_fnc comp, const void *key ) {
    // base case, not found the key
    if ( node == NULL ) return NULL;

    int res = comp( node->key, key );
    // the key may be in the left subtree
    if ( res > 0 ) return get_( node->left, comp, key );
    // the key may be in the right subtree
    else if ( res < 0 ) return get_( node->right, comp, key );

    // found the key, return the value and the node
    return node->val;
}

//-------------------------------------------------------
// cleanup
//-------------------------------------------------------

void rbt_cleanup( RBTree_t *tree ) {
    cleanup_( tree->root, tree->val_decon );
}

void cleanup_( RBNode_t *root, rbt_free_func val_deconstructor ) {
    if ( root == NULL ) return;

    cleanup_( root->left, val_deconstructor );
    cleanup_( root->right, val_deconstructor );

    if ( val_deconstructor != NULL ) val_deconstructor( root );
    free( root );
}

bool rbt_is_empty( const RBTree_t *tree ) {
    return tree->root == NULL || tree->root->size == 0;
}

Vector_t *rbt_keys( const RBTree_t *tree ) {
    Vector_t *keys = calloc(1, sizeof( Vector_t ) );
    vector_capacity(
        keys,
        // avoid expanding during insertion
        tree->root->size + 1
    );

    keys_( tree->root, keys );
    return keys;
}

void keys_( const RBNode_t *node, Vector_t *keys ) {
    if ( node == NULL ) return;

    keys_( node->left, keys );
    vec_append( keys, ( void * ) node->key );
    keys_( node->right, keys );
}

size_t rbt_max_depth( const RBTree_t *tree ) {
    return max_depth_( tree->root );
}

size_t max_depth_( const RBNode_t *node ) {
    if ( node == NULL ) return 0;

    size_t left_depth = max_depth_( node->left );
    size_t right_depth = max_depth_( node->right );

    return ( left_depth > right_depth ? left_depth : right_depth ) + 1;
}