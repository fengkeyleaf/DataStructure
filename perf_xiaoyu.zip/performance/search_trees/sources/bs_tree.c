#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "../includes/bs_tree.h"

/**
 * Is the key or value null?
 *
 * @param key The key to check. Aborted if null.
 * @param val The value to check. If null, remove the entry.
 * */

static bool is_null( const void *key, const void *val );

/**
 * Get the size of the subtree rooted at node n recursively.
 * */

static inline size_t size_( BSNode_t *n );

/**
 * Update the size of the subtree rooted at node n recursively.
 * */

static inline BSNode_t *update_size( BSNode_t *node );

static BSNode_t *put_( BSNode_t *node, bst_compare_fnc comp, const void *key, void *val );
static void *get_( const BSNode_t *node, bst_compare_fnc comp, const void *key );
static void cleanup_( BSNode_t *root, bst_free_func val_deconstructor );
static void keys_( const BSNode_t *node, Vector_t *keys );
static size_t max_depth_( const BSNode_t *node );

bool is_null( const void *key, const void *val ) {
    if ( key == NULL ) {
        perror( "key in put() of BSTree is null\n" );
        exit( 1 );
    }
    if ( val == NULL ) {
        // TODO: enable delete();
        // delete( key );
        return true;
    }

    return false;
}

size_t size_( BSNode_t *n ) {
    if ( n == NULL ) return 0;
    return n->size;
}

BSNode_t *update_size( BSNode_t *n ) {
    n->size = size_( n->left ) + size_( n->right ) + 1;
    return n;
}

//-------------------------------------------------------
// put method
//-------------------------------------------------------

void bst_put(
    BSTree_t *tree, const void *key, void *val
) {
    if ( is_null( key, val ) ) return;

    tree->root = put_( tree->root, tree->comp, key, val );
}

BSNode_t *put_( BSNode_t *node, bst_compare_fnc comp, const void *key, void *val ) {
    // base case, attach the new node to this position
    if ( node == NULL ) {
        BSNode_t *n = ( BSNode_t * ) calloc( 1, sizeof( BSNode_t ) );
        assert( n );
        n->key = key;
        n->val = val;
        n->size = 1;
        return n;
    }

    int res = comp( node->key, key );
    // the node should be attached in the left subtree
    if ( res > 0 ) node->left = put_( node->left, comp, key, val );
    // the node should be attached in the right subtree
    else if ( res < 0 ) node->right = put_( node->right, comp, key, val );
    // added before, update value
    else node->val = val;

    // update size and restore this R-B tree
    return update_size( node );
}

//-------------------------------------------------------
// get method
//-------------------------------------------------------

void *bst_get( const BSTree_t *tree, const void *key ) {
    if ( key == NULL ) {
        perror( "key in get() of BSTree is null\n" );
        exit( 1 );
    }

    return get_( tree->root, tree->comp, key );
}

// Same as get_ in RBTree.
void *get_( const BSNode_t *node, bst_compare_fnc comp, const void *key ) {
    // base case, not found the key
    if ( node == NULL ) return NULL;

    int res = comp( node->key, key );
    // the key may be in the left subtree
    if ( res > 0 ) return get_( node->left, comp, key );
    // the key may be in the right subtree
    else if ( res < 0 ) return get_( node->right, comp, key );

    // found the key, return the value and the node
    return node->val;
}

//-------------------------------------------------------
// cle method
//-------------------------------------------------------

void bst_cleanup( BSTree_t *tree ) {
    cleanup_( tree->root, tree->val_decon );
}

void cleanup_( BSNode_t *root, bst_free_func val_deconstructor ) {
    if ( root == NULL ) return;

    cleanup_( root->left, val_deconstructor );
    cleanup_( root->right, val_deconstructor );

    if ( val_deconstructor != NULL ) val_deconstructor( root );
    free( root );
}

bool bst_is_empty( const BSTree_t *tree ) {
    return tree->root == NULL || tree->root->size == 0;
}

Vector_t *bst_keys( const BSTree_t *tree ) {
    Vector_t *keys = calloc(1, sizeof( Vector_t ) );
    vector_capacity(
        keys,
        // avoid expanding during insertion
        tree->root->size + 1
    );

    keys_( tree->root, keys );
    return keys;
}

void keys_( const BSNode_t *node, Vector_t *keys ) {
    if ( node == NULL ) return;

    keys_( node->left, keys );
    vec_append( keys, ( void * ) node->key );
    keys_( node->right, keys );
}


size_t bst_max_depth( const BSTree_t *tree ) {
    return max_depth_( tree->root );
}

size_t max_depth_( const BSNode_t *node ) {
    if ( node == NULL ) return 0;

    size_t left_depth = max_depth_( node->left );
    size_t right_depth = max_depth_( node->right );

    return ( left_depth > right_depth ? left_depth : right_depth ) + 1;
}