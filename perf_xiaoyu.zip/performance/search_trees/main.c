#include <stdio.h>
#include <stdlib.h>

#include "./includes/rb_tree.h"

int char_compare( const void *a, const void *b ) {
    const char *ia = a;
    const char *ib = b;
    return ( *ia > *ib ) - ( *ia < *ib );
}

void inorder_print_( const RBNode_t *root ) {
    if ( root == NULL ) return;

    inorder_print_( root->left );
    printf( "%c => %d, ", * ( ( char* ) root->key ), * ( ( int* ) root->val ) );
    inorder_print_( root->right );
}

void inorder_print( const RBNode_t *root ) {
    inorder_print_( root );
    printf( "\n" );
}

int main( int argc, char *argv[] ) {
    RBTree_t tree = { NULL,char_compare, NULL };

    char S = 'S';
    size_t num1 = 1;
    rbt_put( &tree, &S, &num1 );
    char E = 'E';
    size_t num2 = 2;
    rbt_put( &tree, &E, &num2 );
    char A = 'A';
    size_t num3 = 3;
    rbt_put( &tree, &A, &num3 );
    char R = 'R';
    size_t num4 = 4;
    rbt_put( &tree, &R, &num4 );
    char C = 'C';
    size_t num5 = 5;
    rbt_put( &tree, &C, &num5 );
    char H = 'H';
    size_t num6 = 6;
    rbt_put( &tree, &H, &num6 );
    char X = 'X';
    size_t num7 = 7;
    rbt_put( &tree, &X, &num7 );
    char M = 'M';
    size_t num8 = 8;
    rbt_put( &tree, &M, &num8 );
    char P = 'P';
    size_t num9 = 9;
    rbt_put( &tree, &P, &num9 );
    char L = 'L';
    size_t num10 = 10;
    rbt_put( &tree, &L, &num10 );

    inorder_print( tree.root );

    printf( "get=%d\n", *( ( int * ) rbt_get( &tree, &M ) ) ); // 8
    printf( "get=%d\n", *( ( int * ) rbt_get( &tree, &A ) ) ); // 3
    printf( "get=%d\n", *( ( int * ) rbt_get( &tree, &X ) ) ); // 7
    char O = 'O';
    void *res = rbt_get( &tree, &O );
    if ( res == NULL ) printf( "get=null" );

    rbt_cleanup( &tree );
    return 0;
}