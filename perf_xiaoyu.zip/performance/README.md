# Project Structure

- `performace/`
  - `concordance_generator/`: Read an input file, generate a tree and output a concordance.
  - `search_tress/`: Implement search trees with generic type support, including binary search trees and red-black trees.
  - `vector/`: Implement a dynamic array (vector) data structure with generic type support.

# Data Downloading and Pre-processing

1. Download the text files from [1 Billion Word Language Model Benchmark](https://www.statmt.org/lm-benchmark/).
2. Unzip the downloaded files to extract the text files, and put them in the `./performance/experiments/` directory.

after downloading and unzipping, your directory structure should look like this:
```
experiments/
└── 1-billion-word-language-modeling-benchmark-r13output/
    ├── heldout-monolingual.tokenized.shuffled
    ├── training-monolingual.tokenized.shuffled
```

3. Pre-process the text files to generate sorted and raw token files using the provided Python script `tokens.py`. 
This script only generates tokens for the data files in the `heldout-monolingual.tokenized.shuffled` directory.
Change the input file to generate tokens for other files if needed.
```python
# --- configuration ---
input_folders = [
    "./1-billion-word-language-modeling-benchmark-r13output/heldout-monolingual.tokenized.shuffled"
    # "./1-billion-word-language-modeling-benchmark-r13output/training-monolingual.tokenized.shuffled"
]  # your two foldersoutput_file = "sorted/all_tokens.txt"
```

# Compilation and Execution

This project is structured using CMakeLists files. To compile and run the code, follow these steps:

1. install PCRE2 and pkg-config, which are required dependencies to process tokens using regular expressions:
```bash
# On Ubuntu or Debian-based systems:
sudo apt update
sudo apt install libpcre2-dev pkg-config

# On macOS using Homebrew:
brew install pcre2 pkg-config
```
2. make a build directory:
   ```bash
   mkdir build && cd build
   ```
3. run cmake to configure the project:
   ```bash
    cmake ..
   ```
4. compile the project using make:
   ```bash
   make
   ```
5. run the desired executable, which is located in:
   ```bash
   ./build/concordance_generator/con_gen
   ```
   
# Experiment Configuration

Since I did not have enough time to set up automated experiment configurations, you can manually change the code or CMakeLists to test different functionalities as needed.

There are three experiments implemented in the project:

## 1. Two different implementations of search trees

To use BST or RBT, you can modify the file in `./performance/concordance_generator/main.c/`

```c
// in void process_tokens( RBTree_t *rb_tree, BSTree_t *bs_tree );
// insert into trees
bst_insert( bs_tree, key );
// rbt_insert( rb_tree, key );
```

## 2. Enabling time profiler

To enable the time profiler, you can uncomment the following line in `./concordance_generator/CMakeLists.txt`:

```cmake
# Add -pg only to this target, cannot use valgrind with -pg.
#target_compile_options(con_gen PRIVATE -pg)
#target_link_options(con_gen PRIVATE -pg)
```

And then recompile the project. This will allow you to use gprof for profiling the performance of the concordance generator.

## 3. Tree depth

The program automatically calculates and prints the depth of the tree after processing the tokens.

However, I do provide executables in the `./performance/experiments` directory for your convenience. You could run the RUN file to see the results of the experiments directly.

```bash
# run bst with sorted tokens or raw tokens:
./RUN bst_raw_mea
./RUN bst_sorted_mea

# run bst with sorted tokens or raw tokens:
./RUN rbt_raw_mea
./RUN rbt_sorted_mea

# Print the depths of the trees with the two input files.
./RUN bst_depth
./RUN rbt_depth
```