# p4_inswitch_anomaly
Repository of Code for In-Switch Anomaly Detection using P4 and Sketches

# action.txt
This file defines actions for the decision tree that is then used when it classifies something.
It is likely this file will need to be tweaked slightly.

# basic.p4
P4 File that defines a sketch and uses this with a decision tree to decide if a packet is part
of a DDoS attacke and drop it accordingly.  Currently not compiling due to errors with externs
such as the "Random" and "Register" types.

# big_tree.txt
This file is the text file representation of the original tree model that was generated without
any depth limiting in place.  It has been very minimally modified from the original model.

# label.py
Python script that reads in two CSV files that contains an unlabeled sequence of packets, and
then assigns either a label of '0' (normal) or '1' (attack) to the packets.  The criteria
for being labeled '1' is to either have the same IP as a known attacker's IP from the UNB
dataset (since that was the attack dataset I used for this project), otherwise it is given
the label '0'.

This is then written out to a new CSV file that is named the third argument when running it.

# sketch_write.py
This file reads in a CSV file that is a labeled sequence of packets, and then after reading
a packet writes out to another CSV file the sketch and the label of the packet.

Note that it may be beneficial to change the way it formats the output eventually.

# small_tree.txt
This file is the text file representation of the original tree model that was generated with
a depth limit of 5.  It has been very minimally modified from the original model.

# tree.py
This file takes in the output of sketch_write.py and uses it to train and output a decision tree.
If (when) the output of sketch_write.py is changed, this file will also need to be (slightly)
changed.
