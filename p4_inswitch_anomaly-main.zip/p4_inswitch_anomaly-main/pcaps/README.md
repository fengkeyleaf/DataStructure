# PCAPS
This folder contains a link to the ucap.rar file.  This file has all of the UNB attack traffic that is of the form UCAP.
I chose the UCAP data from all of the available data because it was a large enough amount of packets while still having
a total file size under the full 40 GB of traffic from the original zipped archive that I downloaded.

Each of the pcap files inside of here should have already been run through Pcapfix, though if there are errors when
trying to merge them or read them in wireshark, then this means that they were not run through Pcapfix.

Link to ucap.rar: https://drive.google.com/file/d/1RE82k7_DjcCjFGD2QD454cTEmUM3Jld7/view?usp=share_link
