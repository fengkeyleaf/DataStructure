###
# Example_Data.py takes a single attack csv and a directory to csvs of benign data to create a sample dataset
#   that is in the same format as the final create_dataset will be.
#
# Riley McGinn
###

